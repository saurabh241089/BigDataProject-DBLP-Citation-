/*********Project Submission***********/

Input Format class:  DBLPInputFormat.java
Driver Class: PageRankDriver.java
Mapper Class: PageRankMapper.java
Reducer Class: PageRankReducer.java
Hive Query: Proj Query.txt

Map reduce output:	Link.txt
Hive script output: paper_rank.txt
Project Report: Project Report.pdf 
Project PPT: Projet PPT